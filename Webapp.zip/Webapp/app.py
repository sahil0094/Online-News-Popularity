from __future__ import print_function
import flask
import joblib
from werkzeug.utils import secure_filename
import os
from nltk.tokenize import word_tokenize
import string
import re
import seaborn as sns
import matplotlib.pyplot as plt
from textblob import TextBlob
import pandas as pd
from io import BytesIO
import plotly
import plotly.graph_objs as go
import plotly.express as px
import json
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
from matplotlib.figure import Figure
import numpy as np


#import pandas as pd

UPLOAD_FOLDER = 'D:/GreatLearning/Capstone/Article_Upload'
ALLOWED_EXTENSIONS = set(['txt'])


# Use pickle to load in the pre-trained model.
with open(f'D:/GreatLearning/Capstone/Webapp/model/Random_Forest.pkl', 'rb') as f:
    model = joblib.load(f)

app = flask.Flask(__name__, template_folder='templates')
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH']=10*1024*1024
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1] in ALLOWED_EXTENSIONS

def clean_text(text):
    # lower text
    text = text.lower()

    # remove puncutation
    text = text.translate(str.maketrans('', '', string.punctuation))

    # tokenize_text
    text = [word for word in word_tokenize(text)]

    # remove words that contain numbers
    text = [word for word in text if not any(c.isdigit() for c in word)]

    # remove empty tokens
    text = [t for t in text if len(t) > 0]

    # remove words with only one letter
    text = [t for t in text if len(t) > 1]

    # join all
    text = " ".join(text)
    return(text)

@app.after_request
def add_header(response):
    # response.cache_control.no_store = True
    response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, post-check=0, pre-check=0, max-age=0'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '-1'
    return response




@app.route('/', methods=['GET', 'POST'])
def main():
    if flask.request.method == 'GET':
        return(flask.render_template('main.html'))
    if flask.request.method == 'POST':
        Title=flask.request.form['title']
        Article = flask.request.files['article']
        if Article and allowed_file(Article.filename):
            filename = secure_filename(Article.filename)
            Article.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        day = flask.request.form['days']
        #assigning value to day columns
        if day=="Monday":
            weekday_is_monday=1
            weekday_is_tuesday=weekday_is_wednesday=weekday_is_thursday=weekday_is_saturday=is_weekend=0
        elif day=="Tuesday":
            weekday_is_tuesday=1
            weekday_is_monday=weekday_is_wednesday=weekday_is_thursday=weekday_is_saturday=is_weekend=0
        elif day=="Wednesday":
            weekday_is_wednesday=1
            weekday_is_monday=weekday_is_tuesday=weekday_is_thursday=weekday_is_saturday=is_weekend=0
        elif day=="Thursday":
            weekday_is_thursday=1
            weekday_is_monday=weekday_is_tuesday=weekday_is_wednesday=weekday_is_saturday=is_weekend=0
        elif day=="Saturday":
            weekday_is_saturday=is_weekend=1
            weekday_is_monday=weekday_is_tuesday=weekday_is_wednesday=weekday_is_thursday=0
        else:
            weekday_is_monday=weekday_is_tuesday=weekday_is_wednesday=weekday_is_thursday=weekday_is_saturday=is_weekend=0

        channel = flask.request.form['channel']
        if channel=="Lifestyle":
            data_channel_is_entertainment=data_channel_is_bus=data_channel_is_socmed=data_channel_is_tech=data_channel_is_world=0
        elif channel=="Entertainment":
            data_channel_is_entertainment=1
            data_channel_is_bus=data_channel_is_socmed=data_channel_is_tech=data_channel_is_world=0
        elif channel=="Business":
            data_channel_is_bus=1
            data_channel_is_entertainment=data_channel_is_socmed=data_channel_is_tech=data_channel_is_world=0
        elif channel=="Social Media":
            data_channel_is_socmed=1
            data_channel_is_entertainment=data_channel_is_bus=data_channel_is_tech=data_channel_is_world=0
        elif channel=="Tech":
            data_channel_is_tech=1
            data_channel_is_entertainment=data_channel_is_bus=data_channel_is_socmed=data_channel_is_world=0
        elif channel=="World":
            data_channel_is_world=1
            data_channel_is_entertainment=data_channel_is_bus=data_channel_is_socmed=data_channel_is_tech=0
        num_imgs=flask.request.form['images']
        num_videos=flask.request.form['videos']
        num_hrefs=flask.request.form['links']
        num_self_hrefs=flask.request.form['self_link']
        print(f'{day}')

        #Reading news article uploaded
        f=open(UPLOAD_FOLDER+'/'+filename,'r')
        text=f.read()
        f.close()

        #Cleaning the text
        # lower text
        text=clean_text(str(text))
        #print(f'Text {text}')
        Title=clean_text(str(Title))
        #print(f'title {Title}')
        #Tokens in article
        n_tokens_content=len(word_tokenize(text))
        #print(f'tokens {n_tokens_content}')
        #Global subjectivity
        global_subjectivity=TextBlob(text).sentiment[1]

        #Title subjectivity
        title_subjectivity=TextBlob(Title).sentiment[1]

       #Title sentiment polarity
        title_sentiment_polarity=TextBlob(Title).sentiment[0]

       #Keywords
        num_keywords=flask.request.form['keyword']

        X=pd.DataFrame([[n_tokens_content, num_hrefs, num_self_hrefs, num_imgs, num_videos, num_keywords,
      data_channel_is_entertainment, data_channel_is_bus, data_channel_is_socmed, data_channel_is_tech,
      data_channel_is_world,weekday_is_monday, weekday_is_tuesday, weekday_is_wednesday, weekday_is_thursday,
      weekday_is_saturday, is_weekend, global_subjectivity,
      title_subjectivity, title_sentiment_polarity]],columns=['n_tokens_content', 'num_hrefs', 'num_self_hrefs', 'num_imgs', 'num_videos', 'num_keywords',
      'data_channel_is_entertainment', 'data_channel_is_bus', 'data_channel_is_socmed', 'data_channel_is_tech',
      'data_channel_is_world','weekday_is_monday', 'weekday_is_tuesday', 'weekday_is_wednesday', 'weekday_is_thursday',
      'weekday_is_saturday', 'is_weekend', 'global_subjectivity',
      'title_subjectivity', 'title_sentiment_polarity'])
        #print(f'values {X.to_numpy()}')

        #X[['num_hrefs', 'num_self_hrefs','num_imgs', 'num_videos','num_keywords']]=X[['num_hrefs', 'num_self_hrefs','num_imgs', 'num_videos','num_keywords']].apply(pd.to_numeric)
        #print(f'{X.dtypes}')
        prediction=model.predict_proba(X)[:,1]

        print(f'{prediction}')
        #return prediction
        #input_variables = pd.DataFrame([[temperature, humidity, windspeed]],
                                      # columns=['temperature', 'humidity', 'windspeed'],
                                       #dtype=float)
        #prediction = model.predict(input_variables)[0]
        #return flask.render_template('main.html',
                                     #original_input={'n_tokens_content':n_tokens_content, 'num_hrefs':num_hrefs, 'num_self_hrefs':num_self_hrefs,
                                      #'num_imgs':num_imgs, 'num_videos':num_videos, 'num_keywords':num_keywords,
                                     #'data_channel_is_entertainment':data_channel_is_entertainment, 'data_channel_is_bus':data_channel_is_bus,
                                     # 'data_channel_is_socmed':data_channel_is_socmed, 'data_channel_is_tech':data_channel_is_tech,
                                     #'data_channel_is_world':data_channel_is_world,'weekday_is_monday':weekday_is_monday,
                                     #'weekday_is_tuesday':weekday_is_tuesday, 'weekday_is_wednesday':weekday_is_wednesday, 'weekday_is_thursday':weekday_is_thursday,
                                     #'weekday_is_saturday':weekday_is_saturday, 'is_weekend':is_weekend, 'global_subjectivity':global_subjectivity,
                                     #'title_subjectivity':title_subjectivity, 'title_sentiment_polarity':title_sentiment_polarity},
                                     #result=prediction,
                                     #)


        #p=create_plot(prediction)
        #return flask.render_template('main.html',plot=p)


        #img=BytesIO()
        #fig.savefig(img)
        #img.seek(0)

        #<img src="/result" alt="popularity" height="200"/>


        fig,ax=plt.subplots()
        plt.pie([prediction,1-prediction],autopct="%.2f",colors=['forestgreen','red'],labels=['Popular','Unpopular'])
        ax.axis('equal')
        plt.title("Online News Popularity Prediction")
        plt.legend()
        path='static/images/image_{}.png'.format(np.random.randint(1,100,1).item())
        print(f'{path}')
        plt.savefig(path)

        return flask.render_template('main.html',url=path)
        #return str(prediction)
        #return flask.send_file(img,mimetype='image/png')



        #return flask.render_template('main.html',figure=fig1)
        #labels=[str(prediction)]
        #values=[.34]
        #colors=["#228B22"]
        #return flask.render_template('pie.html',title='Article Popularity Prediction', max=1, set=zip(values,labels,colors))
